	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="style/lib/bootstrap/css/bootstrap.css">
	<link rel="stylesheet" href="style/lib/font-awesome/css/font-awesome.css">
	<script src="style/lib/jquery-1.11.1.min.js" type="text/javascript"></script>

	<!-- Datatable Style Sheet -->
	<script language="JavaScript" src="https://cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
	<script language="JavaScript" src="https://cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/3/dataTables.bootstrap.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/plug-ins/3cfcc339e89/integration/bootstrap/3/dataTables.bootstrap.css">

	<script language="JavaScript" src="style/lib/custom/custom.js" type="text/javascript"></script>
	<script language="JavaScript" src="layout/site_script.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="style/stylesheets/money_recept.css">
	<link rel="stylesheet" type="text/css" href="style/css/table.css">

     