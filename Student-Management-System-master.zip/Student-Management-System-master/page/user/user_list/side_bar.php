

<nav class="nav-sidebar">
      <ul class="nav">
                    
        <li onclick="add_user()" class="nav_button"><span class='glyphicon glyphicon-plus'></span> Add User</li>
        <div id="btn_sidebar">
        	<li onclick="get_user_list('all')" class="nav_button"><span class="glyphicon glyphicon-user"></span> All User List</li>
        	<li onclick="get_user_list('active')"class="nav_button"><span class="glyphicon glyphicon-user"></span> Active User List</li>
        	<li onclick="get_user_list('deactive')" class="nav_button"><span class="glyphicon glyphicon-user"></span> Deactive User List</li>
        	<li onclick="get_user_list('techserm')" class="nav_button"><span class="glyphicon glyphicon-user"></span> TechSerm User List</li>
        	<li onclick="get_user_list('institute')" class="nav_button"><span class="glyphicon glyphicon-user"></span> Institute User List</li>
         </div>           
        </ul> 
</nav>
 