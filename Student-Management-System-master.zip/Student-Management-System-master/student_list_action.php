<?php

include 'layout/header_script.php';
include "page_action/student_list/student_list.php";

?>