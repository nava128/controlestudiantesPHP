<?php

//Con esto se realiza la conexion a la base de Datos MySQL
//Servidor, Usuario, Contraseña, y Base de datos
$Con = new mysqli('localhost','root','','dbsr');
//Ledigo a que base de datos se conecte
//mysql_select_db("conalepbd",$con);

?>