<br>
<br>
<br>
<br>
<br>
<br>
    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row" style="text-align: center;">
                <div class="col-lg-12">

                    <ul class="list-inline">
                        <li>
                            <a href="panel.php">Panel</a>
                        </li>

                    </ul>
                    <img src="img/logo1.png" alt="Conalep" width="50" height="50" />
                    <h1 style="font-size: 60%;">Plantel San Felipe GTO.</h1>
                    <p>
                      copyright&copy; Sistema de asignacion de areas @2016<br> Arguello #306,
                      Col. Oriental, San Felipe, Gto. C.P. 37600 
                    </p>
                </div>
            </div>
        </div>
    </footer>
